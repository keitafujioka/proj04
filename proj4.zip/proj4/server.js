const path = require('path');
const express = require('express');
const session = require('express-session');

const app = express();
const PORT = process.env.PORT || 3000;

// ---- ユーザーデータ（サンプル用にハードコード） ----
const USERS = {
  user1: { password: 'password1', displayName: '太郎' },
  user2: { password: 'password2', displayName: '花子' },
  user3: { password: 'password3', displayName: '三郎' },
};

app.use(express.urlencoded({ extended: false }));
app.use(express.json());
app.use(
  session({
    secret: 'sample-secret-change-me',
    resave: false,
    saveUninitialized: false,
    cookie: { httpOnly: true, maxAge: 1000 * 60 * 30 }, // 30分
  })
);

// ---- 認証が必要なページを守るミドルウェア ----
function requireLogin(req, res, next) {
  if (req.session && req.session.user) return next();
  return res.redirect('/login.html');
}

// ---- API ----
app.post('/api/login', (req, res) => {
  const { username, password } = req.body || {};
  const user = USERS[username];
  if (!user || user.password !== password) {
    return res.status(401).json({ error: 'ユーザー名またはパスワードが正しくありません。' });
  }
  req.session.user = { username, displayName: user.displayName };
  res.json({ ok: true });
});

app.post('/api/logout', (req, res) => {
  req.session.destroy(() => res.json({ ok: true }));
});

app.get('/api/me', (req, res) => {
  if (!req.session || !req.session.user) {
    return res.status(401).json({ error: '未ログインです。' });
  }
  res.json(req.session.user);
});

// ---- 保護されたページ ----
app.get(['/', '/home.html'], requireLogin, (req, res) => {
  res.sendFile(path.join(__dirname, 'protected', 'home.html'));
});

app.get('/profile.html', requireLogin, (req, res) => {
  res.sendFile(path.join(__dirname, 'protected', 'profile.html'));
});

// ---- 公開ページ（ログイン画面など） ----
app.use(express.static(path.join(__dirname, 'public')));

app.listen(PORT, () => {
  console.log(`サンプルアプリ起動: http://localhost:${PORT}`);
});
