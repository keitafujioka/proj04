import { test, chromium } from "@playwright/test";

test.setTimeout(10 * 60 * 1000);
const authFile = 'auth/subscriberState.json';

test.use({ storageState: 'auth/subscriberState.json' });

test("太郎", async () => {
  const browser = await chromium.connectOverCDP("http://localhost:9222");
  const context = browser.contexts()[0] ?? (await browser.newContext());
  const page = context.pages()[0] ?? (await context.newPage());
  
  await page.goto('http://localhost:3000/profile.html');
  

  // 3. ログインボタンをクリック
  await page.getByRole('button', { name: 'Log in' }).click();
  console.log('ログインボタンをクリックしました。');

  // 4. 管理画面へ遷移するまで待機（2要素認証の完了を待つ）
  await page.waitForURL(/\/wp-admin(\/|$)/, { timeout: 10 * 60 * 1000 });

  // 5. ログイン状態をファイルに保存
  await context.storageState({ path: authFile });
  await context.close();
});