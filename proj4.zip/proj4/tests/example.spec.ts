import { test, expect } from '@playwright/test';

test('ログイン必須ページに直接アクセスして検証できること', async ({ page }) => {
  // ログイン画面を経由せずにマイページへアクセス
  await page.goto('https://example.com/dashboard');

  // Cookieが適用されているため、ログイン済みの要素が検証可能
  await expect(page.getByRole('heading', { name: 'ようこそ' })).toBeVisible();
});
