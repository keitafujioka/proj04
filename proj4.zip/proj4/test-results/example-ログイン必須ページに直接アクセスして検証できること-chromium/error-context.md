# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: example.spec.ts >> ログイン必須ページに直接アクセスして検証できること
- Location: tests\example.spec.ts:3:5

# Error details

```
Error: expect(locator).toBeVisible() failed

Locator: getByRole('heading', { name: 'ようこそ' })
Expected: visible
Error: element(s) not found

Call log:
  - Expect "toBeVisible" getByRole('heading', { name: 'ようこそ' }) with timeout 5000ms
  - waiting for getByRole('heading', { name: 'ようこそ' })
  - Target page, context or browser has been closed

```

```yaml
- paragraph: This domain is for use in documentation examples without needing permission. This is not a service; avoid relying on it for testing and monitoring purposes.
- paragraph: هذا النطاق مُخصص للاستخدام في أمثلة التوثيق دون الحاجة إلى إذن. هذه ليست خدمة، يُرجى تجنب الاعتماد عليها لأغراض الاختبار والمراقبة.
- paragraph: 该域名仅用于文档示例，无需获得许可。这并非一项服务，请勿将其用于测试和监控目的。
- paragraph: L’usage de ce domaine est réservé à des exemples de documentation, sans autorisation préalable. Il ne s’agit pas d’un service ; son utilisation à des fins de test ou de surveillance est à éviter.
- paragraph: Данный домен предназначен для использования в примерах документации без необходимости получения предварительного разрешения. Это не сервис; не рекомендуется его использование для тестирования и мониторинга.
- paragraph: Este dominio está destinado al uso en ejemplos de documentación sin necesidad de permiso. Esto no es un servicio; evitar utilizarlo para realizar pruebas o monitoreos.
- link "Learn more":
  - /url: https://iana.org/help/example-domains
```

# Test source

```ts
  1  | import { test, expect } from '@playwright/test';
  2  | 
  3  | test('ログイン必須ページに直接アクセスして検証できること', async ({ page }) => {
  4  |   // ログイン画面を経由せずにマイページへアクセス
  5  |   await page.goto('https://example.com/dashboard');
  6  | 
  7  |   // Cookieが適用されているため、ログイン済みの要素が検証可能
> 8  |   await expect(page.getByRole('heading', { name: 'ようこそ' })).toBeVisible();
     |                                                             ^ Error: expect(locator).toBeVisible() failed
  9  | });
  10 | 
```