# ログイン + Profile サンプルWebアプリ

ログインすると「ホーム」画面に **Profile** リンクが表示され、`profile.html` に移動すると
ログイン中のユーザー名（アカウント表示名）が表示されるサンプルです。

## 使い方

```bash
npm install
npm start
```

ブラウザで http://localhost:3000 を開きます（未ログインなら `/login.html` に転送されます）。

## サンプルアカウント

| ユーザー名 | パスワード | 表示名 |
|-----------|-----------|--------|
| user1     | password1 | 太郎   |
| user2     | password2 | 花子   |
| user3     | password3 | 三郎   |

## 構成

| ファイル | 役割 |
|---------|------|
| `server.js` | Express サーバー。セッション認証、ログインAPI、ページ保護 |
| `public/login.html` | ログイン画面（未認証でもアクセス可） |
| `protected/home.html` | ログイン後のホーム画面。Profile リンクを表示 |
| `protected/profile.html` | ログイン中のユーザー名を表示 |

## 認証の仕組み

- `POST /api/login` でユーザー名/パスワードを検証し、`express-session` でセッションに保存
- `GET /api/me` で現在のログインユーザー情報（`username` / `displayName`）を返す
- `/`、`/home.html`、`/profile.html` は未ログインだと `/login.html` にリダイレクト
- `POST /api/logout` でセッション破棄

> ※ サンプルのためパスワードは平文・ハードコードです。本番では利用しないでください。
